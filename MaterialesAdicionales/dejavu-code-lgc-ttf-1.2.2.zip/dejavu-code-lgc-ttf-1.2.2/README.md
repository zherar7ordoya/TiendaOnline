DejaVu Sans Code: monospaced font with programming ligatures
---------------------------

DejaVu Sans Code is monospaced font with programming ligatures based on DejaVu
Sans Mono. This repository is a fork of the
[DejaVu fonts repository](https://github.com/dejavu-fonts/dejavu-fonts).

<img src="./sample.png">

[Download latest release](https://github.com/SSNikolaevich/DejaVuSansCode/releases/latest).
There are two variants of font available. One with all glyphs included and other with only the LGC (Latin-Greek-Cyrillic) subset.

Currently implemented symbols
---------------------------
    == != ~= === !== <!-- <-- <- -> --> <= >= => <=> ++ ::

Supported editors
---------------------------
+ KDE Applications: Konsole, KWrite, Kate, KDevelop, etc (Partially.
  Disabling substitution for long sequences of '=' or '+' doesn't work).
+ Intellij IDEA
+ Qt Creator
+ Atom
+ Libre Office

